package com.example.bkfire_junction_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
