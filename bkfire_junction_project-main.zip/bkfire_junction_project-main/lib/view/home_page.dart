import 'package:flutter/material.dart';
import 'package:bkfire_junction_project/modelview/Auth_Controller.dart';
import 'package:get/get.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: const Text('Home page in progress...'),
      ),
    );
  }
}
