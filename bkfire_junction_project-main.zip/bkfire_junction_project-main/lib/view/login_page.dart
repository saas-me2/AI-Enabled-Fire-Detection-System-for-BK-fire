// ignore_for_file: prefer_const_constructors
import 'package:bkfire_junction_project/modelview/Auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Loginpage extends GetWidget<AuthController> {
  Loginpage({super.key});
  GlobalKey<FormState> _key = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 60),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 200,
                  width: 250,
                  child: GestureDetector(
                    onTap: () {},
                    child: Image.asset(
                      'assets/images/bkfire.png',
                    ),
                  ),
                ),
                SizedBox(
                  height: 0,
                ),
                const Text(
                  'Welcome !',
                  style: TextStyle(
                    fontSize: 24,
                    fontFamily: 'PoppinsSemiBold',
                  ),
                ),
                const Text(
                  'Please enter your login details below',
                  style: TextStyle(
                      fontSize: 16,
                      fontFamily: 'PoppinsRegular',
                      color: Colors.black45),
                ),
                SizedBox(
                  height: 20,
                ),
                Form(
                    key: _key,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'User ID',
                            style: TextStyle(
                                color: Color(0xFFCE6645),
                                fontSize: 18,
                                fontFamily: 'PoppinsSemiBold'),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFCE6645)),
                                borderRadius: BorderRadius.circular(10.0)),
                            child: TextFormField(
                              controller: controller.email,
                              decoration: InputDecoration(
                                  hintText: 'Email',
                                  hintStyle:
                                      TextStyle(fontFamily: 'PoppinsRegular'),
                                  border: InputBorder.none,
                                  icon: Image.asset(
                                    'assets/icons/Person@1x.png',
                                    scale: 2,
                                  )),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Text(
                            'Password',
                            style: TextStyle(
                                color: Color(0xFFCE6645),
                                fontSize: 18,
                                fontFamily: 'PoppinsSemiBold'),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(30, 10, 0, 10),
                            decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFCE6645)),
                                borderRadius: BorderRadius.circular(10.0)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Flexible(
                                  child: TextField(
                                    controller: controller.password,
                                    obscuringCharacter: '*',
                                    obscureText: true,
                                    decoration: InputDecoration(
                                        hintText: '**********',
                                        border: InputBorder.none,
                                        icon: Icon(
                                          Icons.password_sharp,
                                          size: 30,
                                          color: Colors.black,
                                        )),
                                  ),
                                ),
                                MaterialButton(
                                  onPressed: () {},
                                  child: Image.asset(
                                    'assets/icons/hide.png',
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: GestureDetector(
                              onTap: () {},
                              child: Text(
                                'Forgot Password?',
                                style: TextStyle(
                                    fontFamily: 'PoppinsMedium',
                                    fontSize: 16,
                                    color: Colors.black87),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          GestureDetector(
                            onTap: () {
                              controller.signin();
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Color(0xFFCE6645),
                                  borderRadius: BorderRadius.circular(17)),
                              height: 69,
                              width: 366,
                              child: Center(
                                child: Text(
                                  'Login',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'PoppinsSemiBold',
                                      fontSize: 20),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: GestureDetector(
                              onTap: () {},
                              child: RichText(
                                text: const TextSpan(
                                    text: 'Don\'t have an account? ',
                                    style: TextStyle(
                                        color: Colors.black87,
                                        fontFamily: 'PoppinsMedium',
                                        fontSize: 16),
                                    children: [
                                      TextSpan(
                                        text: 'Sign up ! ',
                                        style: TextStyle(
                                            color: Color(0xFFCE6645),
                                            fontFamily: 'PoppinsMedium',
                                            fontSize: 18),
                                      ),
                                    ]),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 40,
                          )
                        ],
                      ),
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
