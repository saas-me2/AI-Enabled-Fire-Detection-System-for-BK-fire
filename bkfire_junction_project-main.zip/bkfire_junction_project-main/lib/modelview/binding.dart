import 'package:bkfire_junction_project/modelview/Auth_controller.dart';
import 'package:get/get.dart';

class MyBindings implements Bindings {
  @override
  void dependencies() {
    Get.put(AuthController());
  }
}
