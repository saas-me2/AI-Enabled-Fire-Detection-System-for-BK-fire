import 'package:bkfire_junction_project/view/home_page.dart';
import 'package:bkfire_junction_project/view/login_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthController extends GetxController {
  FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  void onClose() {
    email.dispose();
    password.dispose();
    super.onClose();
  }

  void signin() async {
    try {
      await _auth.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text.trim());
      Get.to(() => HomePage());
    } catch (e) {
      Get.snackbar('error occured', e.toString());
    }
  }

  void signout() async {
    await _auth.signOut();
    Get.offAll(() => Loginpage());
  }
}
